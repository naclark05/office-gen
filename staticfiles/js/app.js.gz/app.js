$(document).ready(function(){
	// when class is clicked
	$('#new-episode').click(function(){
		// load html file into the div
		$('.c1').load("display.html");

	});
});


